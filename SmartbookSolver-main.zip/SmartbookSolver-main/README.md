# SmartbookSolver
A simple Chrome Extension to solve your SmartBook 2.0 Homework
